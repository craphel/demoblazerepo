import { Login } from "../pages/Login";
import{test,expect} from '@playwright/test'
import creds from '../utils/logincreds.json'
import userdetails from '../utils/details.json'

test('Validlogin',async ({page})=>{
    const login=new Login(page)
    await login.openApplication()
    await login.Login(creds[0].username,creds[0].password)
    await login.validUser()
})